import cv2 as cv

class Window:
    def __init__(self, img, label):
        cv.namedWindow(label, cv.WINDOW_NORMAL)
        cv.resizeWindow(label, 600, 400)
        cv.imshow(label, img)



