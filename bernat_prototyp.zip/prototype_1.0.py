import sys
import cv2 as cv
import numpy as np

import Window as w


def main(argv):

    # Loads an image
    src = cv.imread('parkingLot.png')


    # smoothing
    # median = cv.medianBlur(src, 5)
    bilateral = cv.bilateralFilter(src, 9, 75, 75)



    # Canny Edge Detector
    # edges1 = cv.Canny(median, 50, 200)
    edges2 = cv.Canny(bilateral, 150, 200)


    # Hough lines trasformation
    houghLineImage = np.copy(src)
    lines = cv.HoughLinesP(edges2, rho=1, theta=np.pi / 180, threshold=15, minLineLength=180, maxLineGap=50)

    if lines is not None:
        for i in range(0, len(lines)):
            l = lines[i][0]
            cv.line(houghLineImage, (l[0], l[1]), (l[2], l[3]), (0,0,255), 1, cv.LINE_AA)

    # showing windows
    w.Window(src, "source")
    # w.Window(bilateral, "smooth")
    w.Window(edges2, "Edges 150")
    w.Window(houghLineImage, "lines")




    # Wait and Exit
    cv.waitKey()
    cv.destroyAllWindows()
    return 0


if __name__ == "__main__":
    main(sys.argv[1:])